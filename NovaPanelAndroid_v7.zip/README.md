# NovaPanel V7

NovaPanel V7 organiza as funções em um catálogo vertical na lateral esquerda do painel:
- **Desemp.**: métricas disponíveis do próprio processo, frequência de atualização da tela e indicador FPS N/D.
- **Mira**: sobreposição crosshair, formatos cruz/ponto/círculo, cores verde/roxo/branco e tamanho ajustável.
- **Ajustes**: transparência do painel, preferências locais e atalhos para configurações Android/bateria.

Mantém o painel flutuante arrastável, botão de recolher/reabrir e visual preto com roxo neon. O cronômetro e os perfis manuais de sensibilidade não fazem parte desta versão.

O indicador N/D não mede o FPS real do Standoff 2. A frequência da tela em Hz não é o FPS do jogo. A sobreposição da mira depende da permissão Android de exibir sobre outros aplicativos.

## Compilação
Importe o ZIP no repositório e atualize o workflow GitHub Actions para extrair `NovaPanelAndroid_v7.zip`. Execute `gradle assembleDebug` no projeto extraído.
