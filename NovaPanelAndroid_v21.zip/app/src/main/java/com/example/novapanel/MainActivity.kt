package com.example.novapanel

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private var waitingForOverlayPermission = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(android.graphics.Color.rgb(18, 16, 27))
        }
        val title = TextView(this).apply {
            text = "NOVA PANEL V21\nPainel flutuante para Android"
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(247, 244, 255))
        }
        val subtitle = TextView(this).apply {
            text = "Mira visual personalizável • Monitor de tela • Preferências locais\n\nPara usar sobre outros aplicativos, autorize a sobreposição nas configurações do Android."
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(177, 168, 199))
            setPadding(0, 18, 0, 22)
        }
        val button = Button(this).apply {
            text = "Ativar painel flutuante"
            setOnClickListener { activatePanel() }
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(button)
        setContentView(layout)
    }

    private fun activatePanel() {
        if (!Settings.canDrawOverlays(this)) {
            waitingForOverlayPermission = true
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                waitingForOverlayPermission = false
            }
            return
        }
        startPanelService()
    }

    override fun onResume() {
        super.onResume()
        if (waitingForOverlayPermission && Settings.canDrawOverlays(this)) {
            waitingForOverlayPermission = false
            startPanelService()
        }
    }

    private fun startPanelService() {
        startService(Intent(this, FloatingPanelService::class.java))
        finish()
    }
}
