# NovaPanel V21

Painel flutuante Android com visual preto e roxo neon, pensado para utilidades visuais e monitoramento local durante jogos.

## Recursos
- Botão flutuante arrastável para recolher e reabrir o painel.
- Navegação lateral: Desempenho, Mira e Ajustes.
- Crosshair visual: cruz, ponto ou círculo; cores verde, roxo e branco; tamanho e opacidade ajustáveis.
- Sobreposição da mira centralizada, não focável e não tocável para não capturar os toques do jogo.
- Métricas locais: memória usada pelo próprio NovaPanel e taxa de atualização da tela em Hz, atualizadas automaticamente enquanto o painel está aberto.
- Indicador opcional `FPS: N/D`; um app Android comum não consegue obter automaticamente o FPS real de outro jogo por meio dessa implementação.
- Preferência para salvar ou não alterações localmente.
- Atalhos para configurações gerais e bateria.
- Botão de fechar encerra o serviço e remove as sobreposições.

## Limitações importantes
- O aplicativo precisa da autorização Android **Exibir sobre outros apps**.
- A sobreposição pode ser escondida pelo Android ou pelo próprio jogo em algumas telas.
- Hz da tela não é o FPS do jogo. CPU/GPU e temperatura do jogo não são apresentados como se fossem leituras reais.
- O APK precisa ser compilado e testado num dispositivo real; a integridade do ZIP não comprova compilação ou funcionamento.

## Compilar pelo GitHub Actions

1. Extraia o conteúdo deste ZIP na raiz de um repositório Android (os arquivos `settings.gradle`, `build.gradle`, `app/` e `.github/` devem ficar na raiz).
2. Faça commit/push.
3. Abra **Actions → Build NovaPanel Android → Run workflow** (ou faça push para `main`/`master`).
4. Baixe o artefato `NovaPanel-V21-debug-apk` quando o workflow terminar com sucesso.

O workflow usa JDK 17, Gradle 8.2.1 e Android SDK 34. A compilação e os testes em aparelho ainda precisam ser confirmados pelo resultado do GitHub Actions.
