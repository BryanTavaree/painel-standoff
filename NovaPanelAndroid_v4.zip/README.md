# NovaPanel V4
Painel flutuante demonstrativo para Android. Inclui botão flutuante N arrastável, controle de transparência e três chaves que controlam estados internos do próprio painel. Não altera outros aplicativos ou jogos.

## Compilação
Projeto Android Gradle com Java 17/Kotlin JVM target 17. Para compilar: `gradle assembleDebug`.
