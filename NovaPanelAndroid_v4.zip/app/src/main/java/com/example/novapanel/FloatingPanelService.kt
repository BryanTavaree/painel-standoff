package com.example.novapanel

import android.app.Service
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var bubble: TextView? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private val bg = Color.rgb(18, 16, 27)
    private val surface = Color.rgb(34, 29, 48)
    private val purple = Color.rgb(165, 105, 255)
    private val white = Color.rgb(247, 244, 255)
    private val muted = Color.rgb(177, 168, 199)
    private val controlStates = BooleanArray(3)

    private fun rounded(color: Int, radius: Float, strokeColor: Int = Color.TRANSPARENT, strokeWidth: Int = 0) =
        GradientDrawable().apply { setColor(color); cornerRadius = radius; if (strokeWidth > 0) setStroke(strokeWidth, strokeColor) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel != null || bubble != null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
        return START_NOT_STICKY
    }

    private fun overlayParams(width: Int, height: Int, x: Int, y: Int) = WindowManager.LayoutParams(
        width, height, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun makeDraggable(view: View, params: WindowManager.LayoutParams, onTap: (() -> Unit)? = null) {
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt(); val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > dp(4) || kotlin.math.abs(dy) > dp(4)) moved = true
                    params.x = startX + dx; params.y = startY + dy
                    try { wm.updateViewLayout(view, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) onTap?.invoke(); true }
                else -> true
            }
        }
    }

    private fun showPanel() {
        if (panel != null) return
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble = null; bubbleParams = null
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(bg, dp(20).toFloat(), purple, dp(1)); elevation = dp(12).toFloat()
        }
        box.layoutParams = LinearLayout.LayoutParams(dp(286), LinearLayout.LayoutParams.WRAP_CONTENT)
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2), dp(2), dp(2), dp(10)) }
        val mark = TextView(this).apply { text = "N"; textSize = 19f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = rounded(purple, dp(12).toFloat()) }
        header.addView(mark, LinearLayout.LayoutParams(dp(38), dp(38)))
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        heading.addView(TextView(this).apply { text = "NOVA PANEL"; textSize = 16f; setTextColor(white); setTypeface(null, android.graphics.Typeface.BOLD) })
        heading.addView(TextView(this).apply { text = "V4 • PERSONALIZÁVEL"; textSize = 9f; setTextColor(muted) })
        header.addView(heading, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val minimize = TextView(this).apply { text = "—"; textSize = 24f; gravity = Gravity.CENTER; setTextColor(muted); setOnClickListener { showBubble() } }
        header.addView(minimize, LinearLayout.LayoutParams(dp(34), dp(38)))
        val close = TextView(this).apply { text = "×"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(muted); setOnClickListener { showBubble() } }
        header.addView(close, LinearLayout.LayoutParams(dp(28), dp(38)))
        box.addView(header)
        box.addView(View(this).apply { setBackgroundColor(Color.rgb(62, 49, 85)) }, LinearLayout.LayoutParams(-1, dp(1)))
        box.addView(TextView(this).apply { text = "CONTROLES INTERNOS"; textSize = 10f; setTextColor(purple); setPadding(dp(3), dp(12), dp(3), dp(7)); setTypeface(null, android.graphics.Typeface.BOLD) })
        val status = TextView(this).apply { text = statusText(); textSize = 10f; setTextColor(muted); setPadding(dp(3), 0, dp(3), dp(8)) }
        val labels = listOf("Efeito visual 1", "Efeito visual 2", "Efeito visual 3")
        labels.forEachIndexed { index, label ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(4), dp(8), dp(4)); background = rounded(surface, dp(12).toFloat()) }
            row.addView(TextView(this).apply { text = "✦"; textSize = 15f; gravity = Gravity.CENTER; setTextColor(purple) }, LinearLayout.LayoutParams(dp(28), dp(38)))
            row.addView(TextView(this).apply { text = label; textSize = 13f; setTextColor(white) }, LinearLayout.LayoutParams(0, dp(42), 1f))
            val toggle = Switch(this).apply {
                isChecked = controlStates[index]; buttonTintList = ColorStateList.valueOf(purple); thumbTintList = ColorStateList.valueOf(purple)
                setOnCheckedChangeListener { _, checked -> controlStates[index] = checked; status.text = statusText(); Toast.makeText(this@FloatingPanelService, "$label ${if (checked) "ligado" else "desligado"}", Toast.LENGTH_SHORT).show() }
            }
            row.addView(toggle)
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(7); box.addView(row, lp)
        }
        box.addView(status)
        box.addView(TextView(this).apply { text = "TRANSPARÊNCIA DO PAINEL"; textSize = 10f; setTextColor(muted); setPadding(dp(3), dp(3), dp(3), dp(2)) })
        val seek = SeekBar(this).apply {
            max = 100; progress = 100; progressTintList = ColorStateList.valueOf(purple); thumbTintList = ColorStateList.valueOf(Color.rgb(220, 199, 255))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { box.alpha = 0.45f + (progress / 100f) * 0.55f }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        box.addView(seek, LinearLayout.LayoutParams(-1, dp(38)))
        val footer = TextView(this).apply { text = "MINIMIZAR PARA BOTÃO FLUTUANTE"; textSize = 11f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD); background = rounded(purple, dp(12).toFloat()); setPadding(dp(10), dp(12), dp(10), dp(12)); setOnClickListener { showBubble() } }
        val footerLp = LinearLayout.LayoutParams(-1, -2); footerLp.topMargin = dp(7); box.addView(footer, footerLp)
        val params = overlayParams(-2, -2, dp(20), dp(130))
        panel = box; panelParams = params
        wm.addView(box, params)
        makeDraggable(header, params)
    }

    private fun statusText(): String = "Ativos: ${controlStates.count { it }} de 3"

    private fun showBubble() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel = null; panelParams = null
        if (bubble != null) return
        val b = TextView(this).apply {
            text = "N"; textSize = 20f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = rounded(purple, dp(28).toFloat(), Color.rgb(220, 199, 255), dp(2)); elevation = dp(10).toFloat()
        }
        val params = overlayParams(dp(56), dp(56), dp(18), dp(220))
        bubble = b; bubbleParams = params; wm.addView(b, params)
        makeDraggable(b, params) { showPanel() }
        Toast.makeText(this, "NovaPanel minimizado. Arraste o N ou toque para abrir.", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; bubble = null; super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
