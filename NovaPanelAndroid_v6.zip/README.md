# NovaPanel V6

Painel flutuante Android demonstrativo com tema preto/roxo neon, botão arrastável, transparência ajustável, preferências locais, monitor de memória do próprio painel, frequência de atualização da tela, contador de FPS com indicação N/D e crosshair flutuante configurável.

## Alterações do V6
- Removidos os perfis de sensibilidade e o cronômetro.
- Crosshair agora pode ser ativado como sobreposição central sobre outros aplicativos, além da prévia dentro do painel.
- Formato (cruz, ponto ou círculo), cor e tamanho atualizam a sobreposição e ficam salvos localmente.
- A mira usa uma camada não clicável para não bloquear os toques no jogo.

## Limitações importantes
- O contador flutuante não obtém o FPS real de outro jogo; mostra `FPS: N/D`.
- A frequência de atualização da tela em Hz não é o FPS do jogo.
- CPU/GPU e temperatura de outro app/dispositivo podem não estar disponíveis para apps comuns.
- A sobreposição precisa da permissão "Exibir sobre outros apps" do Android. O crosshair é uma sobreposição visual genérica; não altera memória, arquivos ou funcionamento interno do jogo.

Compile pelo workflow do GitHub Actions com `gradle assembleDebug`.
