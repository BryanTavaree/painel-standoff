# NovaPanelAndroid

Projeto de exemplo de painel flutuante Android. Os botões são demonstrativos e não interagem com outros aplicativos ou jogos.

Abra no Android Studio e compile o módulo `app` para gerar um APK. O projeto ainda pode precisar de ajustes conforme a versão do Android/Gradle usada.
