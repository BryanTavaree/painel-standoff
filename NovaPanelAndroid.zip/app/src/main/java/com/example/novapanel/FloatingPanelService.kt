package com.example.novapanel

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.Button
import android.widget.TextView
import android.widget.SeekBar
import android.widget.Toast

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel != null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(0xEE20242B.toInt())
        }
        val title = TextView(this).apply {
            text = "NOVA PANEL  •  DEMO"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(4, 4, 4, 12)
        }
        box.addView(title)
        listOf("Opção demonstrativa 1", "Opção demonstrativa 2", "Opção demonstrativa 3").forEach { label ->
            val b = Button(this).apply {
                text = label
                setOnClickListener {
                    Toast.makeText(this@FloatingPanelService, "$label ativada (demonstração)", Toast.LENGTH_SHORT).show()
                }
            }
            box.addView(b)
        }
        val seekLabel = TextView(this).apply {
            text = "Intensidade demonstrativa"
            setTextColor(0xFFFFFFFF.toInt())
        }
        box.addView(seekLabel)
        box.addView(SeekBar(this).apply { max = 100; progress = 50 })
        box.addView(Button(this).apply {
            text = "Fechar painel"
            setOnClickListener { stopSelf() }
        })

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 180 }

        title.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; touchX = event.rawX; touchY = event.rawY; true }
                MotionEvent.ACTION_MOVE -> { params.x = startX + (event.rawX - touchX).toInt(); params.y = startY + (event.rawY - touchY).toInt(); wm.updateViewLayout(box, params); true }
                else -> false
            }
        }
        panel = box
        wm.addView(box, params)
        return START_NOT_STICKY
    }

    private var startX = 0
    private var startY = 0
    private var touchX = 0f
    private var touchY = 0f

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
