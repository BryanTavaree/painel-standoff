package com.example.novapanel

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null

    private val bg = Color.rgb(18, 16, 27)
    private val surface = Color.rgb(34, 29, 48)
    private val purple = Color.rgb(165, 105, 255)
    private val white = Color.rgb(247, 244, 255)
    private val muted = Color.rgb(177, 168, 199)

    private fun rounded(color: Int, radius: Float, strokeColor: Int = Color.TRANSPARENT, strokeWidth: Int = 0): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            if (strokeWidth > 0) setStroke(strokeWidth, strokeColor)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel != null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(bg, dp(20).toFloat(), purple, dp(1))
            elevation = dp(12).toFloat()
        }
        box.layoutParams = LinearLayout.LayoutParams(dp(270), LinearLayout.LayoutParams.WRAP_CONTENT)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(2), dp(2), dp(10))
        }
        val mark = TextView(this).apply {
            text = "N"
            textSize = 19f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(purple, dp(12).toFloat())
        }
        header.addView(mark, LinearLayout.LayoutParams(dp(38), dp(38)))
        val heading = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        heading.addView(TextView(this).apply {
            text = "NOVA PANEL"
            textSize = 16f
            setTextColor(white)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        heading.addView(TextView(this).apply {
            text = "PAINEL PERSONALIZÁVEL • DEMO"
            textSize = 9f
            setTextColor(muted)
        })
        header.addView(heading, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val close = TextView(this).apply {
            text = "×"
            textSize = 26f
            gravity = Gravity.CENTER
            setTextColor(muted)
            setPadding(dp(6), 0, dp(4), dp(2))
            setOnClickListener { stopSelf() }
        }
        header.addView(close, LinearLayout.LayoutParams(dp(30), dp(38)))
        box.addView(header)

        val divider = View(this).apply { setBackgroundColor(Color.rgb(62, 49, 85)) }
        box.addView(divider, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)))

        val status = TextView(this).apply {
            text = "CONTROLES DE DEMONSTRAÇÃO"
            textSize = 10f
            setTextColor(purple)
            setPadding(dp(3), dp(12), dp(3), dp(7))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        box.addView(status)

        listOf("Opção demonstrativa 1", "Opção demonstrativa 2", "Opção demonstrativa 3").forEachIndexed { index, label ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(11), dp(4), dp(10), dp(4))
                background = rounded(surface, dp(12).toFloat())
            }
            val dot = TextView(this).apply {
                text = "✦"
                textSize = 15f
                gravity = Gravity.CENTER
                setTextColor(purple)
            }
            row.addView(dot, LinearLayout.LayoutParams(dp(28), dp(38)))
            val text = TextView(this).apply {
                this.text = label
                textSize = 13f
                setTextColor(white)
            }
            row.addView(text, LinearLayout.LayoutParams(0, dp(42), 1f))
            val toggle = android.widget.Switch(this).apply {
                this.text = ""
                isChecked = false
                buttonTintList = android.content.res.ColorStateList.valueOf(purple)
                setOnCheckedChangeListener { _, checked ->
                    Toast.makeText(this@FloatingPanelService, "$label ${if (checked) "ativada" else "desativada"} (demonstração)", Toast.LENGTH_SHORT).show()
                }
            }
            row.addView(toggle)
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(7)
            box.addView(row, lp)
        }

        val seekLabel = TextView(this).apply {
            text = "INTENSIDADE VISUAL"
            textSize = 10f
            setTextColor(muted)
            setPadding(dp(3), dp(4), dp(3), dp(2))
        }
        box.addView(seekLabel)
        val seek = SeekBar(this).apply {
            max = 100
            progress = 50
            progressTintList = android.content.res.ColorStateList.valueOf(purple)
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.rgb(220, 199, 255))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(69, 57, 91))
        }
        box.addView(seek, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(35)))

        val footer = TextView(this).apply {
            text = "FECHAR PAINEL"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
            background = rounded(purple, dp(12).toFloat())
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { stopSelf() }
        }
        val footerLp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        footerLp.topMargin = dp(7)
        box.addView(footer, footerLp)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(24); y = dp(140) }

        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; touchX = event.rawX; touchY = event.rawY; true }
                MotionEvent.ACTION_MOVE -> { params.x = startX + (event.rawX - touchX).toInt(); params.y = startY + (event.rawY - touchY).toInt(); wm.updateViewLayout(box, params); true }
                else -> false
            }
        }
        panel = box
        wm.addView(box, params)
        return START_NOT_STICKY
    }

    private var startX = 0
    private var startY = 0
    private var touchX = 0f
    private var touchY = 0f

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
