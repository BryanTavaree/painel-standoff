package com.example.novapanel

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private val prefs by lazy { getSharedPreferences("nova_panel_prefs", Context.MODE_PRIVATE) }
    private var panel: LinearLayout? = null
    private var bubble: TextView? = null
    private var fpsBadge: TextView? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var fpsParams: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private var timerRunning = false
    private var timerStartedAt = 0L
    private var timerAccumulated = 0L
    private var timerLabel: TextView? = null
    private val bg = Color.rgb(18, 16, 27)
    private val surface = Color.rgb(34, 29, 48)
    private val purple = Color.rgb(165, 105, 255)
    private val white = Color.rgb(247, 244, 255)
    private val muted = Color.rgb(177, 168, 199)
    private val refreshTimer = object : Runnable {
        override fun run() {
            timerLabel?.text = formatTime(currentTimerMs())
            if (timerRunning) handler.postDelayed(this, 250)
        }
    }

    private fun rounded(color: Int, radius: Float, strokeColor: Int = Color.TRANSPARENT, strokeWidth: Int = 0) =
        GradientDrawable().apply { setColor(color); cornerRadius = radius; if (strokeWidth > 0) setStroke(strokeWidth, strokeColor) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun label(text: String, size: Float = 12f, color: Int = white, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel != null || bubble != null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
        if (prefs.getBoolean("fps_overlay", false)) showFpsBadge()
        return START_NOT_STICKY
    }

    private fun overlayParams(width: Int, height: Int, x: Int, y: Int, notFocusable: Boolean = true) = WindowManager.LayoutParams(
        width, height, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        if (notFocusable) WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE else 0, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun makeDraggable(view: View, params: WindowManager.LayoutParams, onTap: (() -> Unit)? = null) {
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt(); val dy = (event.rawY - downY).toInt()
                    if (abs(dx) > dp(4) || abs(dy) > dp(4)) moved = true
                    params.x = startX + dx; params.y = startY + dy
                    try { wm.updateViewLayout(view, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) onTap?.invoke(); true }
                else -> true
            }
        }
    }

    private fun addSection(box: LinearLayout, title: String) {
        box.addView(label(title.uppercase(Locale.getDefault()), 10f, purple, true).apply { setPadding(dp(3), dp(13), dp(3), dp(7)) })
    }

    private fun addButtonRow(box: LinearLayout, vararg items: Pair<String, () -> Unit>) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        items.forEachIndexed { i, item ->
            val b = Button(this).apply {
                text = item.first; textSize = 10f; isAllCaps = false; setTextColor(white)
                background = rounded(surface, dp(10).toFloat(), purple, dp(1)); setPadding(dp(4), 0, dp(4), 0)
                setOnClickListener { item.second() }
            }
            val lp = LinearLayout.LayoutParams(0, dp(42), 1f); if (i > 0) lp.leftMargin = dp(5); row.addView(b, lp)
        }
        box.addView(row)
    }

    private fun addSwitch(box: LinearLayout, title: String, key: String, default: Boolean, changed: (Boolean) -> Unit = {}) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(3), dp(8), dp(3)); background = rounded(surface, dp(11).toFloat())
        }
        row.addView(label(title, 12f), LinearLayout.LayoutParams(0, dp(44), 1f))
        val sw = Switch(this).apply {
            buttonTintList = ColorStateList.valueOf(purple); thumbTintList = ColorStateList.valueOf(purple)
            isChecked = prefs.getBoolean(key, default)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(key, on).apply(); changed(on) }
        }
        row.addView(sw)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(6); box.addView(row, lp)
    }

    private fun showPanel() {
        if (panel != null) return
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble = null; bubbleParams = null
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(13), dp(12), dp(13), dp(12))
            background = rounded(bg, dp(19).toFloat(), purple, dp(1)); elevation = dp(12).toFloat()
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2), dp(2), dp(2), dp(9)) }
        header.addView(TextView(this).apply { text = "N"; textSize = 19f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = rounded(purple, dp(12).toFloat()) }, LinearLayout.LayoutParams(dp(38), dp(38)))
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(9), 0, 0, 0) }
        heading.addView(label("NOVA PANEL", 15f, white, true))
        heading.addView(label("V5 • GAMER TOOLS", 9f, muted))
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(this).apply { text = "—"; textSize = 23f; gravity = Gravity.CENTER; setTextColor(muted); setOnClickListener { showBubble() } }, LinearLayout.LayoutParams(dp(32), dp(38)))
        header.addView(TextView(this).apply { text = "×"; textSize = 25f; gravity = Gravity.CENTER; setTextColor(muted); setOnClickListener { showBubble() } }, LinearLayout.LayoutParams(dp(27), dp(38)))
        box.addView(header)
        box.addView(View(this).apply { setBackgroundColor(Color.rgb(62, 49, 85)) }, LinearLayout.LayoutParams(-1, dp(1)))

        val scroll = ScrollView(this).apply { isFillViewport = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        addSection(content, "Desempenho")
        val fpsStatus = label(fpsDescription(), 11f, muted).apply { setPadding(dp(3), 0, dp(3), dp(7)) }
        content.addView(fpsStatus)
        addSwitch(content, "Contador flutuante de FPS", "fps_overlay", false) { on -> if (on) showFpsBadge() else hideFpsBadge(); fpsStatus.text = fpsDescription() }
        val perf = label(performanceText(), 11f, white).apply { setPadding(dp(10), dp(8), dp(10), dp(8)); background = rounded(surface, dp(10).toFloat()) }
        content.addView(perf)
        addButtonRow(content, "Atualizar métricas" to { perf.text = performanceText() }, "Modo Android" to {
            try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            catch (_: Exception) { Toast.makeText(this, "Abra as configurações manualmente", Toast.LENGTH_SHORT).show() }
        })

        addSection(content, "Crosshair • prévia")
        val crossPreview = TextView(this).apply {
            text = crosshairText(); textSize = (18 + prefs.getInt("cross_size", 20)).toFloat(); gravity = Gravity.CENTER; setTextColor(prefs.getInt("cross_color", Color.GREEN))
            background = rounded(Color.rgb(9, 8, 14), dp(12).toFloat()); setPadding(0, dp(10), 0, dp(10))
        }
        content.addView(crossPreview, LinearLayout.LayoutParams(-1, dp(72)))
        addButtonRow(content, "Formato: cruz" to { prefs.edit().putString("cross_shape", "cross").apply(); crossPreview.text = "＋" },
            "Ponto" to { prefs.edit().putString("cross_shape", "dot").apply(); crossPreview.text = "•" },
            "Círculo" to { prefs.edit().putString("cross_shape", "circle").apply(); crossPreview.text = "⊙" })
        addSection(content, "Tamanho da mira")
        val crossSize = SeekBar(this).apply {
            max = 40; progress = prefs.getInt("cross_size", 20); progressTintList = ColorStateList.valueOf(purple); thumbTintList = ColorStateList.valueOf(purple)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) { crossPreview.textSize = (18 + value).toFloat(); prefs.edit().putInt("cross_size", value).apply() }
                override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        content.addView(crossSize)
        addButtonRow(content, "Verde" to { setCrossColor(crossPreview, Color.GREEN) }, "Roxo" to { setCrossColor(crossPreview, purple) }, "Branco" to { setCrossColor(crossPreview, Color.WHITE) })

        addSection(content, "Perfis de sensibilidade")
        val profileLabel = label("Perfil atual: ${prefs.getString("profile", "Equilibrado")}", 11f, muted).apply { setPadding(dp(3), 0, 0, dp(6)) }
        content.addView(profileLabel)
        addButtonRow(content, "Precisão" to { setProfile("Precisão", profileLabel) }, "Equilibrado" to { setProfile("Equilibrado", profileLabel) }, "Rápido" to { setProfile("Rápido", profileLabel) })
        content.addView(label("Os perfis são referências salvas; ajuste a sensibilidade dentro do jogo manualmente.", 10f, muted).apply { setPadding(dp(3), dp(5), dp(3), 0) })

        addSection(content, "Cronômetro")
        timerLabel = label(formatTime(currentTimerMs()), 22f, white, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(3), 0, dp(7)) }
        content.addView(timerLabel)
        addButtonRow(content, "Iniciar / pausar" to { toggleTimer() }, "Zerar" to { timerRunning = false; timerAccumulated = 0L; handler.removeCallbacks(refreshTimer); timerLabel?.text = formatTime(0) })

        addSection(content, "Preferências")
        val alphaText = label("Transparência: ${prefs.getInt("panel_alpha", 100)}%", 10f, muted)
        content.addView(alphaText)
        val alphaSeek = SeekBar(this).apply {
            max = 100; progress = prefs.getInt("panel_alpha", 100); progressTintList = ColorStateList.valueOf(purple); thumbTintList = ColorStateList.valueOf(Color.rgb(220, 199, 255))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) {
                    val actual = value.coerceAtLeast(35); box.alpha = actual / 100f; alphaText.text = "Transparência: $actual%"
                    if (fromUser) prefs.edit().putInt("panel_alpha", actual).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        content.addView(alphaSeek)
        addSwitch(content, "Salvar preferências", "persist", true) { on -> Toast.makeText(this, if (on) "Preferências serão salvas" else "Salvar desativado", Toast.LENGTH_SHORT).show() }
        addButtonRow(content, "Atalhos Android" to {
            try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            catch (_: Exception) { Toast.makeText(this, "Não foi possível abrir configurações", Toast.LENGTH_SHORT).show() }
        }, "Bateria" to {
            try { startActivity(Intent(android.provider.Settings.ACTION_BATTERY_SAVER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            catch (_: Exception) { Toast.makeText(this, "Atalho indisponível neste Android", Toast.LENGTH_SHORT).show() }
        })
        box.addView(scroll, LinearLayout.LayoutParams(dp(300), dp(490)))
        val footer = TextView(this).apply {
            text = "MINIMIZAR PARA BOTÃO FLUTUANTE"; textSize = 10f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
            background = rounded(purple, dp(11).toFloat()); setPadding(dp(8), dp(11), dp(8), dp(11)); setOnClickListener { showBubble() }
        }
        val footerLp = LinearLayout.LayoutParams(-1, -2); footerLp.topMargin = dp(7); box.addView(footer, footerLp)
        val params = overlayParams(-2, -2, dp(12), dp(55))
        panel = box; panelParams = params
        try { wm.addView(box, params); box.alpha = prefs.getInt("panel_alpha", 100).coerceAtLeast(35) / 100f }
        catch (_: Exception) { panel = null; Toast.makeText(this, "Permissão de sobreposição necessária", Toast.LENGTH_LONG).show(); stopSelf(); return }
        makeDraggable(header, params)
    }

    private fun setCrossColor(view: TextView, color: Int) { view.setTextColor(color); prefs.edit().putInt("cross_color", color).apply() }
    private fun crosshairText(): String = when (prefs.getString("cross_shape", "cross")) { "dot" -> "•"; "circle" -> "⊙"; else -> "＋" }
    private fun setProfile(name: String, view: TextView) { prefs.edit().putString("profile", name).apply(); view.text = "Perfil atual: $name"; Toast.makeText(this, "Perfil $name selecionado", Toast.LENGTH_SHORT).show() }
    private fun fpsDescription() = "FPS do jogo: não disponibilizado diretamente por um app comum; a sobreposição indica essa limitação."
    private fun showFpsBadge() {
        if (fpsBadge != null) return
        val badge = TextView(this).apply { text = "FPS: N/D"; textSize = 12f; setTextColor(white); setPadding(dp(10), dp(7), dp(10), dp(7)); background = rounded(bg, dp(10).toFloat(), purple, dp(1)); alpha = 0.92f }
        val params = overlayParams(-2, -2, dp(110), dp(30))
        fpsBadge = badge; fpsParams = params
        try { wm.addView(badge, params); makeDraggable(badge, params) { Toast.makeText(this, "O Android não fornece FPS real do jogo para este app.", Toast.LENGTH_LONG).show() } }
        catch (_: Exception) { fpsBadge = null; Toast.makeText(this, "Não foi possível mostrar a sobreposição", Toast.LENGTH_SHORT).show() }
    }
    private fun hideFpsBadge() { fpsBadge?.let { try { wm.removeView(it) } catch (_: Exception) {} }; fpsBadge = null; fpsParams = null }
    private fun performanceText(): String {
        val runtime = Runtime.getRuntime(); val used = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
        val max = runtime.maxMemory() / (1024 * 1024)
        val refresh = try { @Suppress("DEPRECATION") (wm.defaultDisplay.refreshRate).toInt() } catch (_: Exception) { 0 }
        return "RAM usada pelo NovaPanel: ${used} MB / ${max} MB\nTela: ${refresh} Hz (não é FPS do jogo)\nCPU/GPU e temperatura do jogo: leitura restrita pelo Android."
    }
    private fun currentTimerMs(): Long = timerAccumulated + if (timerRunning) System.currentTimeMillis() - timerStartedAt else 0L
    private fun toggleTimer() {
        if (timerRunning) { timerAccumulated = currentTimerMs(); timerRunning = false; handler.removeCallbacks(refreshTimer) }
        else { timerStartedAt = System.currentTimeMillis(); timerRunning = true; handler.post(refreshTimer) }
    }
    private fun formatTime(ms: Long): String { val seconds = ms / 1000; return String.format(Locale.getDefault(), "%02d:%02d", seconds / 60, seconds % 60) }
    private fun statusText(): String = "NovaPanel V5 ativo"

    private fun showBubble() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel = null; panelParams = null
        if (bubble != null) return
        val b = TextView(this).apply { text = "N"; textSize = 20f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = rounded(purple, dp(28).toFloat(), Color.rgb(220, 199, 255), dp(2)); elevation = dp(10).toFloat() }
        val params = overlayParams(dp(56), dp(56), dp(18), dp(220))
        bubble = b; bubbleParams = params
        try { wm.addView(b, params); makeDraggable(b, params) { showPanel() } }
        catch (_: Exception) { bubble = null; stopSelf() }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        hideFpsBadge(); panel = null; bubble = null; super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
