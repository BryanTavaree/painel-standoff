# NovaPanel V5

Painel flutuante Android demonstrativo com tema preto/roxo neon, botão arrastável, transparência ajustável, preferências locais, perfis manuais de sensibilidade, cronômetro, prévia de crosshair e ferramentas de desempenho.

## Limitações importantes
- O contador flutuante é um indicador de disponibilidade: apps Android comuns não recebem automaticamente o FPS real de outro jogo. A tela em Hz não representa o FPS do jogo.
- CPU/GPU e temperatura de outro app/dispositivo podem não estar disponíveis sem APIs ou permissões específicas.
- O crosshair desta versão é apenas uma prévia dentro do painel.
- Perfis de sensibilidade são referências para ajuste manual no jogo.

Compile com Gradle pelo GitHub Actions (`gradle assembleDebug`). O projeto exige a permissão Android de sobreposição para mostrar o painel.
